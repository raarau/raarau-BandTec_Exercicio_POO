﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_4
{
	class Program
	{
		static void Main(string[] args)
		{
			//Atribui os valores dos atributos para classe produto chocolate.
			Produto chocolate = new Produto();
			chocolate.categoria = "Doce.";
			chocolate.nome = "Chocolate.";
			chocolate.preco = 4.50f;
			chocolate.codigo = 1000014545;

			//Atribui os valores dos atributos para classe produto suco de uva.
			Produto sucoUva = new Produto();
            sucoUva.categoria = "Bebida.";
            sucoUva.nome = "Suco de uva.";
            sucoUva.preco = 12.00f;
            sucoUva.codigo = 1000014343;

			chocolate.Exibir();
            sucoUva.Exibir();
			
			//Aplica parametro de alíquota nos valores estabelecidos para cada objeto. 
			chocolate.AplicarDesconto(0.15f);
            sucoUva.AplicarDesconto(0.20f);
			
            //Exibe o valor total de cada item com o desconto da alíquota.
			chocolate.Exibir();
            sucoUva.Exibir();

			Console.ReadKey();
		}
	}
}
