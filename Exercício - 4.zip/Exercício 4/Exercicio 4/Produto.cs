﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_4
{
	class Produto
	{
        //Atributos da classe Produto.
		public int codigo;
		public string nome;
		public string categoria;
		public float preco;
		
        //Método que exibe cada atributo da classe Produto.
		public void Exibir()
		{
			Console.WriteLine("\nCodigo: {0} \nNome: {1} \nCategoria: {2} \nPreço: {3:C}",this.codigo, this.nome, this.categoria, this.preco);

		}
        //Método que calcula o desconto baseado, na taxa definida na alíquota.
		public void AplicarDesconto(float aliquota)
		{
			this.preco = this.preco - (this.preco*aliquota);
			
		}

	}
}
